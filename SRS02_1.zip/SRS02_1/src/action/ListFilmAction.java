package action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;
import form.ListFilmForm;
import model.bean.Character;
import model.bean.Film;
import model.bean.FilmName;
import model.bean.LiberationTime;
import model.bo.CharacterBO;
import model.bo.FilmBO;
import model.bo.FilmNameBO;
import model.bo.LiberationTimeBO;
import model.dao.FilmDAO;

/**
 * ListFilmAction.java
 *
 * Version 1.0
 *
 * Date: 19-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 19-05-2017        	CuongHM4        Create
 */

public class ListFilmAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ListFilmForm listFilmForm3 = (ListFilmForm) form;

		FilmNameBO filmNameBO = new FilmNameBO();
		ArrayList<FilmName> listFilmName = filmNameBO.getListFilmName();
		listFilmForm3.setListFilmName(listFilmName);

		CharacterBO characterBO = new CharacterBO();
		ArrayList<Character> listCharacter = characterBO.getListCharacter();
		listFilmForm3.setListCharacter(listCharacter);

		LiberationTimeBO liberationTimeBO = new LiberationTimeBO();
		ArrayList<LiberationTime> listLiberationTime = liberationTimeBO.getListLiberationTime();
		listFilmForm3.setListLiberationTime(listLiberationTime);

		String action = listFilmForm3.getAction();

		FilmBO filmBO = new FilmBO();
		int page = 1;
		int recordsPerPage = 4;
		int noOfRecords = 0;
		int noOfRecords1 = 0;
		int noOfPages = 0;
		if (request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
		}
		ArrayList<Integer> listPage = new ArrayList<Integer>();
		ArrayList<Film> listFilm;
		listFilm = filmBO.getListFilm((page - 1) * recordsPerPage, recordsPerPage * page);

		noOfRecords = FilmDAO.getNoOfRecords();
		noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
		for (int i = 1; i <= noOfPages; i++) {
			listPage.add(i);
		}
		listFilmForm3.setListFilm(listFilm);
		listFilmForm3.setListPage(listPage);
		listFilmForm3.setCurrentPage(page);
		listFilmForm3.setNoOfPages(noOfPages);

		Film film = new Film();
		if (null != action && "検索".equals(action)) {
			ActionErrors actionErrors = new ActionErrors();
			if (StringProcess.notVaildLiberationTime(listFilmForm3.getLiberationTimeName())) {
				actionErrors.add("LiberationTimeError", new ActionMessage("error.LiberationTime.trong"));
			}

			if (StringProcess.checkDayofWeek(listFilmForm3.getFilmDayOfWeek())) {
				actionErrors.add("FilmDayOfWeekError", new ActionMessage("error.FilmDayOfWeek.sai"));
			}

			if (StringProcess.checkDayOfYear(listFilmForm3.getFilmDayOfYear())) {
				actionErrors.add("FilmDayOfYearError", new ActionMessage("error.FilmDayOfYear.loi"));
			}

			if (StringProcess.checkTime(listFilmForm3.getFilmTime())) {
				actionErrors.add("FilmTimeError", new ActionMessage("error.FilmTime.loi"));
			}

			String filmName = listFilmForm3.getFilmName();
			String liberationTimeName = listFilmForm3.getLiberationTimeName();
			String characterName = listFilmForm3.getCharacterName();
			String filmDayOfWeek = listFilmForm3.getFilmDayOfWeek();
			String filmDayOfYear = listFilmForm3.getFilmDayOfYear();
			String filmTime = listFilmForm3.getFilmTime();
			film.setCharacterName(characterName);
			film.setFilmName(filmName);
			film.setLiberationTimeName(liberationTimeName);
			film.setFilmDayOfWeek(filmDayOfWeek);
			film.setFilmDayOfYear(filmDayOfYear);
			film.setFilmTime(filmTime);
			saveErrors(request, actionErrors);
			if (actionErrors.size() > 0) {
				return mapping.findForward("searchFilmError");
			}

			if (!"".equals(filmDayOfYear.trim())) {
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Date date1 = simpleDateFormat.parse(liberationTimeName);
				Date date2 = simpleDateFormat.parse(filmDayOfYear);
				if (date1.after(date2)) {
					actionErrors.add("FilmDayOfYearError", new ActionMessage("error.FilmDayOfYear.ngay"));
				}
			}

			saveErrors(request, actionErrors);
			if (actionErrors.size() > 0) {
				return mapping.findForward("searchFilmError");
			} else {
				int page1 = 1;
				int recordsPerPage1 = 4;
				int noOfPages1 = 0;
				if (request.getParameter("page") != null) {
					page1 = Integer.parseInt(request.getParameter("page"));
				}
				ArrayList<Integer> listPage1 = new ArrayList<Integer>();
				ArrayList<Film> listFilm1;
				listFilm1 = filmBO.getSearchFilm(film, (page1 - 1) * recordsPerPage1, recordsPerPage1 * page1);

				noOfRecords1 = FilmDAO.getNoOfRecords1();
				noOfPages1 = (int) Math.ceil(noOfRecords1 * 1.0 / recordsPerPage1);

				for (int i = 1; i <= noOfPages1; i++) {
					listPage1.add(i);
				}

				listFilmForm3.setListFilm(listFilm1);
				listFilmForm3.setListPage(listPage1);
				listFilmForm3.setCurrentPage(page1);
				listFilmForm3.setNoOfPages(noOfPages1);
				return mapping.findForward("listFilm");
			}
		}
		return mapping.findForward("listFilm");
	}
}
