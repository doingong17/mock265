package model.bo;

import java.util.ArrayList;

import model.bean.Character;
import model.dao.CharacterDAO;

/**
 * CharacterBO.java
 *
 * Version 1.0
 *
 * Date: 20-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-05-2017        	CuongHM4        Create
 */

public class CharacterBO {
	CharacterDAO characterDAO = new CharacterDAO();
	
	/**
	 * Hàm get danh sách tất cả Character
	 * @return list
	 */
	public ArrayList<Character> getListCharacter() {
		return characterDAO.getListCharacter();
	}
}
