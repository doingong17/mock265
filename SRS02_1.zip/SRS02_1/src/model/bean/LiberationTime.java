package model.bean;

/**
 * LiberationTime.java
 *
 * Version 1.0
 *
 * Date: 19-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 19-05-2017        	CuongHM4        Create
 */

public class LiberationTime {
	private String liberationTimeId;
	private String liberationTimeName;
	
	public LiberationTime(String liberationTimeId, String liberationTimeName) {
		super();
		this.liberationTimeId = liberationTimeId;
		this.liberationTimeName = liberationTimeName;
	}

	public LiberationTime() {
		super();
	}

	/**
	 * @return the liberationTimeId
	 */
	public String getLiberationTimeId() {
		return liberationTimeId;
	}
	
	/**
	 * @param liberationTimeId the liberationTimeId to set
	 */
	public void setLiberationTimeId(String liberationTimeId) {
		this.liberationTimeId = liberationTimeId;
	}
	
	/**
	 * @return the liberationTimeName
	 */
	public String getLiberationTimeName() {
		return liberationTimeName;
	}
	
	/**
	 * @param liberationTimeName the liberationTimeName to set
	 */
	public void setLiberationTimeName(String liberationTimeName) {
		this.liberationTimeName = liberationTimeName;
	}
	
	@Override
	public String toString() {
		return "LiberationTime [liberationTimeId=" + liberationTimeId + ", liberationTimeName=" + liberationTimeName
				+ "]";
	}

	
}
