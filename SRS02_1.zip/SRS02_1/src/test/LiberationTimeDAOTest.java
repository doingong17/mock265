package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import model.bean.LiberationTime;
import model.dao.LiberationTimeDAO;

public class LiberationTimeDAOTest {
	LiberationTimeDAO liberationTimeDAO;
	protected ArrayList<LiberationTime> listLiberationTimeExpected;
	protected ArrayList<LiberationTime> listLiberationTimeActual;

	@Before
	public void setUp() throws Exception {
		liberationTimeDAO = new LiberationTimeDAO();
		listLiberationTimeExpected = new ArrayList<LiberationTime>();
		listLiberationTimeExpected.add(new LiberationTime("L1","2017/04/01"));
		listLiberationTimeActual = liberationTimeDAO.getListLiberationTime();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testListLiberationTime() {
		assertEquals(listLiberationTimeExpected.get(0).getLiberationTimeId(), listLiberationTimeActual.get(0).getLiberationTimeId());	
		assertEquals(listLiberationTimeExpected.get(0).getLiberationTimeName(), listLiberationTimeActual.get(0).getLiberationTimeName());
	}

}
