package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.LiberationTime;

/**
 * LiberationTimeDAO.java
 *
 * Version 1.0
 *
 * Date: 20-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-05-2017        	CuongHM4        Create
 */


public class LiberationTimeDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=Film";
	String userName = "sa";
	String password = "12345678";
	Connection connection;
	
	/**
	 * Hàm kết nối database
	 */
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Hàm get danh sách tất cả liberationtime
	 * @return list
	 */
	public ArrayList<LiberationTime> getListLiberationTime() {
		connect();
		String sql=	"SELECT LiberationTimeId, LiberationTimeName FROM LiberationTime";
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<LiberationTime> list = new ArrayList<LiberationTime>();
		LiberationTime liberationTime;
		try {
			while(rs.next()){
				liberationTime = new LiberationTime();
				liberationTime.setLiberationTimeId(rs.getString("LiberationTimeId"));
				liberationTime.setLiberationTimeName(rs.getString("LiberationTimeName"));
				list.add(liberationTime);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
}
