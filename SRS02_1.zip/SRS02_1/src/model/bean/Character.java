package model.bean;

/**
 * Character.java
 *
 * Version 1.0
 *
 * Date: 19-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 19-05-2017        	CuongHM4        Create
 */

public class Character {
	private String characterId;
	private String characterName;
	
	
	public Character(String characterId, String characterName) {
		super();
		this.characterId = characterId;
		this.characterName = characterName;
	}
	
	public Character() {
		super();
	}


	/**
	 * @return the characterId
	 */
	public String getCharacterId() {
		return characterId;
	}
	
	/**
	 * @param characterId the characterId to set
	 */
	public void setCharacterId(String characterId) {
		this.characterId = characterId;
	}
	
	/**
	 * @return the characterName
	 */
	public String getCharacterName() {
		return characterName;
	}
	
	/**
	 * @param characterName the characterName to set
	 */
	public void setCharacterName(String characterName) {
		this.characterName = characterName;
	}	
}
