package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.FilmName;

/**
 * FilmNameDAO.java
 *
 * Version 1.0
 *
 * Date: 20-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-05-2017        	CuongHM4        Create
 */

public class FilmNameDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=Film";
	String userName = "sa";
	String password = "12345678";
	Connection connection;
	
	/**
	 * Hàm kết nối database
	 */
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Hàm get danh sách tất cả các film name
	 * @return list
	 */
	public ArrayList<FilmName> getListFilmName() {
		connect();
		String sql=	"SELECT FilmId, FilmName, Constructor, Director, DisplayTime, FilmImage,"
				+ " Trailer, CharacterId, LiberationTimeID FROM Name_Films";
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
		ArrayList<FilmName> list = new ArrayList<FilmName>();
		FilmName filmName;
		try {
			while(rs.next()){
				filmName = new FilmName();
				filmName.setFilmId(rs.getString("FilmId"));
				filmName.setFilmName(rs.getString("FilmName"));
				filmName.setConstructor(rs.getString("Constructor"));
				filmName.setDirector(rs.getString("Director"));
				filmName.setDisplayTime(rs.getString("DisplayTime"));
				filmName.setFilmImage(rs.getString("FilmImage"));
				filmName.setTrailer(rs.getString("Trailer"));
				filmName.setCharacterId(rs.getString("CharacterId"));
				filmName.setLiberationTimeID(rs.getString("LiberationTimeId"));
				list.add(filmName);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return list;
	}
}
