package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.Film;

/**
 * FilmDAO.java
 *
 * Version 1.0
 *
 * Date: 20-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-05-2017        	CuongHM4        Create
 */

public class FilmDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=Film";
	String userName = "sa";
	String password = "12345678";
	Connection connection;
	Statement stmt = null;
	private static int noOfRecords;
	private static int noOfRecords1;	

	/**
	 * Hàm kết nối database
	 */
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Hàm get danh sách tất cả film
	 * @param offset
	 * @param noOfRecords
	 * @return list
	 */
	public ArrayList<Film> getListFilm(int offset, int noOfRecords) {
		connect();
		String sql = "SELECT * " + " FROM ( SELECT f.FilmId, n.FilmName, n.Constructor, n.Director, n.FilmImage, "+
					" c.CharacterName, l.LiberationTimeName, f.FilmDayOfYear, f.FilmTime, "+
					" ROW_NUMBER() over (ORDER BY ID ) as ct from  Name_Films n INNER JOIN Films f ON f.FilmId = n.FilmId "+ 
					" INNER JOIN Characters c ON n.CharacterId = c.CharacterId "+
					" INNER JOIN LiberationTime l ON n.LiberationTimeId = l.LiberationTimeId ) "+
					" sub WHERE ( ct > " + offset + " AND ct <= " + noOfRecords + " ) ";
		ArrayList<Film> list = new ArrayList<Film>();
		Film film;
		ResultSet rs;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				film = new Film();
				film.setFilmId(rs.getString("FilmId"));
				film.setFilmName(rs.getString("FilmName"));
				film.setConstructor(rs.getString("Constructor"));
				film.setDirector(rs.getString("Director"));
				film.setFilmImage(rs.getString("FilmImage"));
				film.setCharacterName(rs.getString("CharacterName"));
				film.setLiberationTimeName(rs.getString("LiberationTimeName"));
				film.setFilmDayOfYear(rs.getString("FilmDayOfYear"));
				film.setFilmTime(rs.getString("FilmTime"));
				list.add(film);
			}
			rs.close();
			rs = stmt.executeQuery("select count(*) as num from Films");
			if (rs.next())
				this.noOfRecords = rs.getInt("num");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	/**
	 * Hàm get danh sách film thỏa điều kiện tìm kiếm
	 * @param film
	 * @param offset
	 * @param noOfRecords
	 * @return list
	 */
	public ArrayList<Film> getSearchFilm(Film film, int offset1, int noOfRecords1) {
		connect();
		String filter ="";
		
		if (!"来ている".equals(film.getLiberationTimeName())){
			filter += " LiberationTimeName = '" + film.getLiberationTimeName() + "'";
		}
		if (!"Doctor-Strange".equals(film.getFilmName())){
			filter += " AND FilmName = '" + film.getFilmName() + "'";
		}
		if (!"Name of character".equals(film.getCharacterName())){
			filter += " AND CharacterName = '" + film.getCharacterName() + "'";
		}
		if (film.getFilmDayOfWeek().trim().length()>0){
			filter += " AND DATENAME(dw,f.FilmDayOfYear) = '" + film.getFilmDayOfWeek() + "'";
		}
		if (film.getFilmDayOfYear().trim().length()>0){
			filter += " AND FilmDayOfYear = '" + film.getFilmDayOfYear() + "'";
		}
		if (film.getFilmTime().trim().length()>0){
			filter += " AND FilmTime = '" + film.getFilmTime() + "'";
		}
		String sql=	"SELECT * FROM  ( SELECT n.FilmName, n.Constructor, n.Director, n.FilmImage, "+
					" c.CharacterName, l.LiberationTimeName, f.FilmDayOfYear, f.FilmTime, "+
					" ROW_NUMBER() over (ORDER BY ID ) as ct, COUNT(ID) over (ORDER BY FilmName ) as NUM from  Name_Films n INNER JOIN Films f ON f.FilmId = n.FilmId "+ 
					" INNER JOIN Characters c ON n.CharacterId = c.CharacterId "+
					" INNER JOIN LiberationTime l ON n.LiberationTimeId = l.LiberationTimeId WHERE " + filter + ")" +
					" sub WHERE ( ct > " + offset1 + " AND ct <= " + noOfRecords1 + " )";
		ResultSet rs;
		ArrayList<Film> list = new ArrayList<Film>();
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()){
				film = new Film();
				film.setFilmName(rs.getString("FilmName"));
				film.setConstructor(rs.getString("Constructor"));
				film.setDirector(rs.getString("Director"));
				film.setFilmImage(rs.getString("FilmImage"));
				film.setCharacterName(rs.getString("CharacterName"));
				film.setLiberationTimeName(rs.getString("LiberationTimeName"));
				film.setFilmDayOfYear(rs.getString("FilmDayOfYear"));
				film.setFilmTime(rs.getString("FilmTime"));
				list.add(film);
			}			
			rs.close();
			rs = stmt.executeQuery(sql);
			if (rs.next())
				this.noOfRecords1 = rs.getInt("NUM");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}	
	
	/**
	 * Hàm thêm 1 phim vào database
	 * @param filmId
	 * @param filmDayOfYear
	 * @param filmTime
	 * @return 
	 */
	public boolean addFilm(String filmId, String filmDayOfYear, String filmTime){
		connect();
		int rows = 0;
		String sql=	String.format("INSERT INTO Films (FilmId, FilmDayOfYear, FilmTime) "+
					" VALUES ('%s','%s','%s')", filmId, filmDayOfYear, filmTime);
		try {
			Statement stmt = connection.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return (rows>=0)?true:false;
	}
	
	/**
	 * Ham lay noOfRecords
	 * 
	 * @return the noOfRecords
	 */
	public static int getNoOfRecords() {
		return noOfRecords;
	}

	/**
	 * Ham gan gia tri cho noOfRecords
	 * 
	 * @param noOfRecords
	 * the noOfRecords to set
	 */
	public void setNoOfRecords(int noOfRecords) {
		this.noOfRecords = noOfRecords;
	}
	
	/**
	 * @return the noOfRecords1
	 */
	public static int getNoOfRecords1() {
		return noOfRecords1;
	}

	/**
	 * @param noOfRecords1 the noOfRecords1 to set
	 */
	public static void setNoOfRecords1(int noOfRecords1) {
		FilmDAO.noOfRecords1 = noOfRecords1;
	}
}
