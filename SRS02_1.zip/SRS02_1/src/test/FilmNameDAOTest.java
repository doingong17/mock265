package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;
import model.bean.FilmName;
import model.dao.FilmNameDAO;

public class FilmNameDAOTest extends TestCase{
	
	FilmNameDAO filmNameDAO;
	FilmName filmName;
	protected ArrayList<FilmName> listFilmNameExpected;
	protected ArrayList<FilmName> listFilmNameActual;
	

	@Before
	public void setUp() throws Exception {
		filmNameDAO = new FilmNameDAO();
		listFilmNameExpected = new ArrayList<FilmName>();
		listFilmNameExpected.add(new FilmName("NF1","ThanKiem","Nam","Quang","2h","1.jpg","1.mp4","C1","L1"));
		listFilmNameActual = filmNameDAO.getListFilmName();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
    public void testListFilmName() {
		assertEquals(listFilmNameExpected.get(0).getFilmId(), listFilmNameActual.get(0).getFilmId());	
		assertEquals(listFilmNameExpected.get(0).getFilmName(), listFilmNameActual.get(0).getFilmName());
		assertEquals(listFilmNameExpected.get(0).getConstructor(), listFilmNameActual.get(0).getConstructor());
		assertEquals(listFilmNameExpected.get(0).getDirector(), listFilmNameActual.get(0).getDirector());
		assertEquals(listFilmNameExpected.get(0).getDisplayTime(), listFilmNameActual.get(0).getDisplayTime());
		assertEquals(listFilmNameExpected.get(0).getFilmImage(), listFilmNameActual.get(0).getFilmImage());	
		assertEquals(listFilmNameExpected.get(0).getTrailer(), listFilmNameActual.get(0).getTrailer());
		assertEquals(listFilmNameExpected.get(0).getCharacterId(), listFilmNameActual.get(0).getCharacterId());
		assertEquals(listFilmNameExpected.get(0).getLiberationTimeID(), listFilmNameActual.get(0).getLiberationTimeID());
    }

}
