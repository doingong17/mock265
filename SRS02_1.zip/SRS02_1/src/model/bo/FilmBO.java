package model.bo;

import java.util.ArrayList;

import model.bean.Film;
import model.dao.FilmDAO;

/**
 * FilmBO.java
 *
 * Version 1.0
 *
 * Date: 20-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-05-2017        	CuongHM4        Create
 */

public class FilmBO {
	
	FilmDAO filmDAO = new FilmDAO();
	
	/**
	 * Hàm get danh sách tất cả film
	 * @param offset
	 * @param noOfRecords
	 * @return list
	 */
	public ArrayList<Film> getListFilm(int offset, int noOfRecords) {
		return filmDAO.getListFilm(offset, noOfRecords);
	}
	
	/**
	 * Hàm get danh sách film thỏa điều kiện tìm kiếm
	 * @param film
	 * @param offset
	 * @param noOfRecords
	 * @return list
	 */
	public ArrayList<Film> getSearchFilm(Film film, int offset, int noOfRecords){
		return filmDAO.getSearchFilm(film, offset, noOfRecords);
	}
	
	/**
	 * Hàm thêm 1 phim vào database
	 * @param filmId
	 * @param filmDayOfYear
	 * @param filmTime
	 * @return list
	 */
	public boolean addFilm(String filmId, String filmDayOfYear, String filmTime){
		return filmDAO.addFilm(filmId, filmDayOfYear, filmTime);
	}
}
