package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;
import model.bean.Character;
import model.dao.CharacterDAO;

public class CharacterDAOTest extends TestCase{
	CharacterDAO characterDAO;
	protected ArrayList<Character> listCharacterExpected;
	protected ArrayList<Character> listCharacterActual;

	@Before
	public void setUp() throws Exception {
		characterDAO = new CharacterDAO();
		listCharacterExpected = new ArrayList<Character>();
		listCharacterExpected.add(new Character("C1","ChanTuDan"));
		listCharacterActual = characterDAO.getListCharacter();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testListCharacter() {
		assertEquals(listCharacterExpected.get(0).getCharacterId(), listCharacterActual.get(0).getCharacterId());	
		assertEquals(listCharacterExpected.get(0).getCharacterName(), listCharacterActual.get(0).getCharacterName());
	}

}
