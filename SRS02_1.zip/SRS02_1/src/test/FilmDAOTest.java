package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;
import model.bean.Film;
import model.bean.FilmName;
import model.dao.CharacterDAO;
import model.dao.FilmDAO;
import model.dao.FilmNameDAO;
import model.dao.LiberationTimeDAO;

public class FilmDAOTest extends TestCase {
	FilmDAO filmDAO;
	Film film;
	FilmName filmName;
	protected ArrayList<Film> listFilmExpected;
	protected ArrayList<Film> listFilmActual;
	/*
	 * protected ArrayList<Film> searchFilmExpected; protected ArrayList<Film>
	 * searchFilmActual;
	 */

	protected boolean addFilmActual;
	int offset;
	int noOfRecords;
	int offset1;
	int noOfRecords1;
	String filmId;
	String filmDayOfYear;
	String filmTime;

	@Before
	public void setUp() throws Exception {
		filmDAO = new FilmDAO();
		offset = 1;
		noOfRecords = 4;
		offset1 = 1;
		noOfRecords1 = 4;
		filmId = "NF2";
		filmDayOfYear = "2017/06/12";
		filmTime = "11:11";
		listFilmExpected = new ArrayList<Film>();
		listFilmExpected.add(
				new Film("2017/06/01", "14:00", "NF2", "VungMau", "ChanTuDan", "2017/04/16", "Tung", "Long", "2.jpg"));
		listFilmActual = filmDAO.getListFilm(offset, noOfRecords);
		/*
		 * searchFilmExpected = new ArrayList<Film>();
		 * searchFilmExpected.add(new Film("2017/06/01", "14:00", "VungMau",
		 * "ChanTuDan", "2017/04/16", "Tung", "Long", "2.jpg"));
		 * searchFilmActual = filmDAO.getSearchFilm(film, offset1,
		 * noOfRecords1);
		 */

		addFilmActual = filmDAO.addFilm(filmId, filmDayOfYear, filmTime);

	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void testAddFilm() {
		assertEquals(true, addFilmActual);
	}

	@Test
	public void testListFilm() {
		assertEquals(listFilmExpected.get(0).getFilmDayOfYear(), listFilmActual.get(0).getFilmDayOfYear());
		assertEquals(listFilmExpected.get(0).getFilmTime(), listFilmActual.get(0).getFilmTime());
		assertEquals(listFilmExpected.get(0).getFilmId(), listFilmActual.get(0).getFilmId());
		assertEquals(listFilmExpected.get(0).getFilmName(), listFilmActual.get(0).getFilmName());
		assertEquals(listFilmExpected.get(0).getCharacterName(), listFilmActual.get(0).getCharacterName());
		assertEquals(listFilmExpected.get(0).getLiberationTimeName(), listFilmActual.get(0).getLiberationTimeName());
		assertEquals(listFilmExpected.get(0).getConstructor(), listFilmActual.get(0).getConstructor());
		assertEquals(listFilmExpected.get(0).getDirector(), listFilmActual.get(0).getDirector());
		assertEquals(listFilmExpected.get(0).getFilmImage(), listFilmActual.get(0).getFilmImage());
	}

	/*
	 * @Test public void testSearchFilm() {
	 * assertEquals(searchFilmExpected.get(0).getFilmDayOfYear(),
	 * searchFilmActual.get(0).getFilmDayOfYear());
	 * assertEquals(searchFilmExpected.get(0).getFilmTime(),
	 * searchFilmActual.get(0).getFilmTime());
	 * assertEquals(searchFilmExpected.get(0).getFilmName(),
	 * searchFilmActual.get(0).getFilmName());
	 * assertEquals(searchFilmExpected.get(0).getCharacterName(),
	 * searchFilmActual.get(0).getCharacterName());
	 * assertEquals(searchFilmExpected.get(0).getLiberationTimeName(),
	 * searchFilmActual.get(0).getLiberationTimeName());
	 * assertEquals(searchFilmExpected.get(0).getConstructor(),
	 * searchFilmActual.get(0).getConstructor());
	 * assertEquals(searchFilmExpected.get(0).getDirector(),
	 * searchFilmActual.get(0).getDirector());
	 * assertEquals(searchFilmExpected.get(0).getFilmImage(),
	 * searchFilmActual.get(0).getFilmImage()); }
	 */
}
